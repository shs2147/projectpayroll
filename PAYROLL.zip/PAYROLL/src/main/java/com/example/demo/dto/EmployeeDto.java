package com.example.demo.dto;
import java.util.List;
import javax.persistence.Id;

import com.example.demo.entities.Position;
public class EmployeeDto {
	
	@Id
	private int id;
	private int empId;
	private String fiistName;
	private String lastName;
	private String middleName;
	private int depId;
	private double salary;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFiistName() {
		return fiistName;
	}
	public void setFiistName(String fiistName) {
		this.fiistName = fiistName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public int getDepId() {
		return depId;
	}
	public void setDepId(int depId) {
		this.depId = depId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
	@Override
	public String toString() {
		return "EmployeeDto [id=" + id + ", empId=" + empId + ", fiistName=" + fiistName + ", lastName=" + lastName
				+ ", middleName=" + middleName + ", depId=" + depId + ", salary=" + salary + "]";
	}
	

	
	private List<Position> positions;


	public List<Position> getPositions() {
		return positions;
	}
	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}
	
	
	
}
