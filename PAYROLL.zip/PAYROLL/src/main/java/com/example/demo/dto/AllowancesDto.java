package com.example.demo.dto;



import javax.persistence.Id;
public class AllowancesDto {

		
		@Id
		private int id;
		private String allowancesDescription;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getAllowancesDescription() {
			return allowancesDescription;
		}
		public void setAllowancesDescription(String allowancesDescription) {
			this.allowancesDescription = allowancesDescription;
		}
		@Override
		public String toString() {
			return "AllowancesDto [id=" + id + ", allowancesDescription=" + allowancesDescription + "]";
		}
		
		
			
		
		
		
	}



