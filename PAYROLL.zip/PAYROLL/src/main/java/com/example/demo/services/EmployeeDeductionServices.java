package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.EmployeeDeductionRepository;
import com.example.demo.dto.EmployeeDeductionDto;
import com.example.demo.entities.EmployeeDeduction;

@Service
public class EmployeeDeductionServices {
	
	
		
		
		@Autowired
		 EmployeeDeductionRepository employeeDeductionRepository;
		
		public void saveEmp(EmployeeDeductionDto empDeductiondto) {
		      employeeDeductionRepository.save(employeeDeductionDtoToEmployeeDeduction(empDeductiondto));
		
		}
		
		public List<EmployeeDeductionDto> getAllPayroll (){
			List<EmployeeDeduction> listPayroll = this.employeeDeductionRepository.findAll();
			List<EmployeeDeductionDto> empDeductions = listPayroll.stream().map(emp -> this.employeeDeductionToemployeeDeductiondto(emp)).collect(Collectors.toList());
			
			return empDeductions;
			
		}
		
			public void deleteempdeduction(int Id) {
			
				employeeDeductionRepository.deleteById(Id);
		}
			
			public EmployeeDeduction savePayroll(EmployeeDeduction employeeDeduction) {
				return employeeDeductionRepository.save(employeeDeduction);
			}
			
			 public EmployeeDeductionDto payrollById(Integer Id)
			    {
			        EmployeeDeduction employeeDeduction = this.employeeDeductionRepository.findById(Id).get();
			        // Optional<Employee> byId = employeeReposatory.findById(employeeId);
			        return this.employeeDeductionToemployeeDeductiondto(employeeDeduction);


}
			 public EmployeeDeduction employeeDeductionDtoToEmployeeDeduction (EmployeeDeductionDto employeeDeductiodto) {
				 
				 
				 EmployeeDeduction emp=new EmployeeDeduction();
				 emp.setAmmount(employeeDeductiodto.getAmmount());
				 emp.setDate_created(employeeDeductiodto.getDate_created());
				 emp.setDeduction_Id(employeeDeductiodto.getDeduction_Id());
				 emp.setEffective_Date(employeeDeductiodto.getEffective_Date());
				 emp.setEmp_Id(employeeDeductiodto.getEmp_Id());
				 emp.setId(employeeDeductiodto.getId());
				 emp.setType(employeeDeductiodto.getType());
				 
				 return emp;				 
			 }

			 public EmployeeDeductionDto employeeDeductionToemployeeDeductiondto(EmployeeDeduction employeeDeduction) {
				 
				 EmployeeDeductionDto dedu=new EmployeeDeductionDto();
				 dedu.setAmmount(employeeDeduction.getAmmount());
				 dedu.setDate_created(employeeDeduction.getDate_created());
				 dedu.setDeduction_Id(employeeDeduction.getDeduction_Id());
				 dedu.setEffective_Date(employeeDeduction.getEffective_Date());
				 dedu.setId(employeeDeduction.getId());
				 dedu.setEmp_Id(employeeDeduction.getEmp_Id());
				 dedu.setType(employeeDeduction.getType());
				 
				 
				 return dedu;
				 
			 }




}
