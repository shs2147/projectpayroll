 package com.example.demo.entities;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name="Employee")
public class Employee {
	
	
	@Id
	private int id;
	private int empId;
	private String fiistName;
	private String lastName;
	private String middleName;
	private int depId;
	private double salary;
	

	


	public int getId() {
		return id;
	}





	public void setId(int id) {
		this.id = id;
	}





	public int getEmpId() {
		return empId;
	}





	public void setEmpId(int empId) {
		this.empId = empId;
	}





	public String getFiistName() {
		return fiistName;
	}





	public void setFiistName(String fiistName) {
		this.fiistName = fiistName;
	}





	public String getLastName() {
		return lastName;
	}





	public void setLastName(String lastName) {
		this.lastName = lastName;
	}





	public String getMiddleName() {
		return middleName;
	}





	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}





	public int getDepId() {
		return depId;
	}





	public void setDepId(int depId) {
		this.depId = depId;
	}





	public double getSalary() {
		return salary;
	}





	public void setSalary(double salary) {
		this.salary = salary;
	}





	public List<Position> getPositions() {
		return positions;
	}





	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}





	@ManyToMany(targetEntity = Position.class,cascade = {CascadeType.ALL})
	@JoinTable(
		name="employeeposition",
		joinColumns = 
		@JoinColumn(name="employeeId",referencedColumnName="id"),
	inverseJoinColumns = @JoinColumn(name="posId", referencedColumnName="positionId"))
	private List<Position> positions;
	
	
	
	

}
