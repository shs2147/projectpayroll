package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.demo.dto.EmployeeDeductionDto;
import com.example.demo.services.EmployeeDeductionServices;

public class EmployeeeductionController {
	

	   @Autowired
    EmployeeDeductionServices deductinServices;

	@PostMapping("/empdeduction")
public ResponseEntity<EmployeeDeductionDto>saveDeduction(@RequestBody EmployeeDeductionDto empeloyeDeductiondto){
	 
	 deductinServices.saveEmp(empeloyeDeductiondto);
	 return new ResponseEntity<>(empeloyeDeductiondto,HttpStatus.CREATED); 
}
@DeleteMapping("/empdeduction/{id}")
public void deleteDeduction(@PathVariable("id")int id ) {
	 
	 deductinServices.deleteempdeduction(id);	 
	 
}
//@PutMapping("/empdeduction") 
//public ResponseEntity<Deductiondto>updateall(@RequestBody Deductiondto deductionDto){
	 
//	 deductinServices.upd(deductionDto);
//	 return new ResponseEntity<>(deductionDto,HttpStatus.CREATED);
}






