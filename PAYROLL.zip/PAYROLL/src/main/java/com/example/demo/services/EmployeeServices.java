package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entities.Employee;

@Service

public class EmployeeServices {
	@Autowired
	EmployeeRepository employeeRepository;
	
	public void saveEmployee(EmployeeDto employeeDto) {
		
		employeeRepository.save(employeeDtoEmployee(employeeDto));
				
	}
	
	public void deleteEmployee(int id)
	{
		employeeRepository.deleteById(id);	
	}
	
	public void updateEmployee(EmployeeDto employeeDto) {
		employeeRepository.save(employeeDtoEmployee(employeeDto));
		
		
	}
	public Employee employeeDtoEmployee(EmployeeDto employeeDto)   {
		
		Employee emp=new Employee();
		emp.setId(employeeDto.getId());
		emp.setEmpId(employeeDto.getEmpId());
		emp.setDepId(employeeDto.getDepId());
		emp.setFiistName(employeeDto.getFiistName());
		emp.setLastName(employeeDto.getLastName());
		emp.setMiddleName(employeeDto.getMiddleName());
		emp.setSalary(employeeDto.getSalary());
		emp.setPositions(employeeDto.getPositions());
		
		return emp;	
		
	}

	public EmployeeDto employeeTOEmployeeDto(Employee employee) {
		EmployeeDto edto=new EmployeeDto();
		edto.setDepId(employee.getDepId());
		edto.setEmpId(employee.getEmpId());
		edto.setFiistName(employee.getFiistName());
		edto.setId(employee.getId());
		edto.setLastName(employee.getLastName());
		edto.setMiddleName(employee.getMiddleName());
		edto.setSalary(employee.getSalary());
		edto.setPositions(employee.getPositions());;
		return edto;
			
	} 
	public List<EmployeeDto> getAllEmployee(){
		   List<Employee> listEmployee= this.employeeRepository.findAll();
		
		   List<EmployeeDto> employeeDto = listEmployee.stream().map(emp ->this.employeeTOEmployeeDto(emp)).collect(Collectors.toList());
		
		return employeeDto;
		
	}
}







