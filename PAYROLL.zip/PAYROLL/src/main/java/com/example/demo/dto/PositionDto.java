package com.example.demo.dto;
import java.util.List;
import javax.persistence.Id;

import com.example.demo.entities.Employee;

public class PositionDto {
	
	
	@Id
	private int departmentid;
	private String name;
	private int positionId;
	
	private List<Employee> employee;
	
	
	public List<Employee> getEmployee() {
		return employee;
	}
	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	public int getPositionId() {
		return positionId;
	}
	public void setPositionId(int positionId) {
		this.positionId = positionId;
	}
	public int getDepartmentid() {
		return departmentid;
	}
	public void setDepartmentid(int departmentid) {
		this.departmentid = departmentid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "PositionDto [departmentid=" + departmentid + ", name=" + name + ", positionId=" + positionId + "]";
	}
	

}
