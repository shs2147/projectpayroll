package com.example.demo.services;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Repository.AllowancesRepository;
import com.example.demo.dto.AllowancesDto;

import com.example.demo.entities.Allowances;

@Service
public class AllowancesServices {
	
	@Autowired
	private AllowancesRepository allowancesRepository;
	 
	public void saveAllowances(AllowancesDto allowancesDto)
	{
	 
		allowancesRepository.save(allowancesDtoToAllowances(allowancesDto));
	 
	 	 		
	}
	
	public void deleteAllowances(int id) {
		
		allowancesRepository.deleteById(id);
	}
	public void updateAllowances(AllowancesDto allowancesDto) {
		
		allowancesRepository.save(allowancesDtoToAllowances(allowancesDto));
	}
	
	
	
	public List<AllowancesDto> getAllAllowances(){
		   List<Allowances> listAllowance= this.allowancesRepository.findAll();
		
		   List<AllowancesDto> allowancesdto  = listAllowance.stream().map(allow ->this.allowancesToAllowancesDto(allow)).collect(Collectors.toList());
		
		return allowancesdto;
		
	}
	
	  public Allowances allowancesDtoToAllowances(AllowancesDto allowancesDto)
	    {
	        Allowances allowances=new Allowances();

	       allowances.setId(allowancesDto.getId());
	       allowances.setAllowancesDescription(allowancesDto.getAllowancesDescription());
	        return allowances;
	    }

	    public AllowancesDto allowancesToAllowancesDto(Allowances allowances)
	    {
	        AllowancesDto allowancesDto= new AllowancesDto();

	        allowancesDto.setId(allowancesDto.getId());

	        allowancesDto.setAllowancesDescription(allowancesDto.getAllowancesDescription());
	        	     
	        return allowancesDto;
	    }

	    



	
	

}
